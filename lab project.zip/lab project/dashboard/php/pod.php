<?php
$host = $_SESSION['db']['hostname'];
$username = $_SESSION['db']['username'];
$password = $_SESSION['db']['password'];
$dbname = $_SESSION['db']['databasename'];


try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>