<?php
$host = $_SESSION['db']['hostname'];
$username = $_SESSION['db']['username'];
$password = $_SESSION['db']['password'];
$dbname = $_SESSION['db']['databasename'];

$conn = new mysqli($host, $username, $password,$dbname);

		// Check connection
		if ($conn->connect_error) {
			 echo 'Connection failed: ' . $conn->connect_error;
		}
		
		

?>