<?php
    session_start();
    require_once('php/pod.php');
    $db_name = $_SESSION['db']['databasename'];
    $responce = new stdClass();
    $data = [];
    $sql = $_POST['query'];
    if($sql == "SHOW TABLES"){
        $tables = $conn->query($sql);        
        $i = 0;
        foreach ($tables as $table) {
             $i = $i+1;
            array_push($data,$table[0]);
        }
        $responce->total_table = $i;
        $responce->tables = $data;
        echo json_encode($responce);      
        
    }
    
    
   exit;

?>