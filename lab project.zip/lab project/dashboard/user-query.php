<?php 
     session_start();
     require_once('php/db.php');
     $db_name = $_SESSION['db']['databasename'];
    $responce = new stdClass();
    $data = [];
    $sql = $_POST['query'];

    if($sql != "SHOW TABLES"){
        $rs_result = mysqli_query ($conn, $sql);
        $col_name = [];
        if($rs_result->num_rows > 0){
        while ($row = mysqli_fetch_array($rs_result)) {
            $col_name = [];
            foreach($row as $key => $value)
            {
                array_push($col_name,$key);
                
            }
            
        }
        }
        else{
            echo "no data found";
        }
        print_r($col_name);
        // echo json_encode($data);
        
    }
?>

