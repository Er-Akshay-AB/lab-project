$(document).ready(function(){
    
    $.ajax({
        type:"POST",
        url:'query.php',
        data:{
            query : "SHOW TABLES"
        },
        beforeSend:function(){
            
        },
        success:function(r){
            var response = JSON.parse(r);
            $('.table-name').html('');
            for (let i = 0; i < response.tables.length; i++) {
                $('.table-name').append('<a class="nav-link" href="layout-static.html">'+response.tables[i]+'</a>')
                
            }
        }
   });
  });

  const textarea = document.querySelector("textarea");
      const numbers = document.querySelector(".numbers");
      textarea.addEventListener("keyup", (e) => {
        const num = e.target.value.split("\n").length;
        numbers.innerHTML = Array(num).fill("<span></span>").join("");
        
      });
      textarea.addEventListener("keydown", (event) => {
        if (event.key === "Tab") {
          const start = textarea.selectionStart;
          const end = textarea.selectionEnd;

          textarea.value =
            textarea.value.substring(0, start) +
            "\t" +
            textarea.value.substring(end);

          event.preventDefault();
        }
      });
$(document).ready(function(){
    $('.sql-submit').click(function(){
        
        $.ajax({
            type:"POST",
            url:'user-query.php',
            data:{
                type:'sql-query',
                query : $("#sql-query").val()
            },
            beforeSend:function(){
                
            },
            success:function(r){
                console.log(r);
                var response = JSON.parse(r);
                for (let i = 0; i < response.length; i++) {
                    // $("#col-name").append("<th>"++"</th>")
                    // console.log(response[i]);
                }
                
                
            }
       });
    });
});