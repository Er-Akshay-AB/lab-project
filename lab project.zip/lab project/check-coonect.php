<?php 
    // error_reporting(0);
    session_start();
		$hostname = $_POST['host'];
		$username = $_POST['username'];
		$password = $_POST['password'];
		$databasename = $_POST['databasename'];
		$conn = new mysqli($hostname, $username, $password,$databasename);

		// Check connection
		if ($conn->connect_error) {
			 echo 'Connection failed: ' . $conn->connect_error;
		}
		$db = [
			'hostname'=>$hostname,
			'username'=>$username,
			'password'=>$password,
			'databasename'=>$databasename
		];
		$_SESSION['db'] = $db;
		echo "done";

	
?>