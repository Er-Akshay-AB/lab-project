<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="./css/index.css" >
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

</head>
<body class="bg-black">
<section class="h-screen ">
  <div class="px-6 h-full text-gray-800">
    <div class="flex xl:justify-center lg:justify-between justify-center items-center flex-wrap h-full g-6">
      <div class="grow-0 shrink-1 md:shrink-0 basis-auto xl:w-6/12 lg:w-6/12 md:w-9/12 mb-12 md:mb-0" >
        <img src="databse-img.jpg" class="w-full" alt="Sample image" />
      </div>
      
      <div class="xl:ml-20 xl:w-5/12 lg:w-5/12 md:w-8/12 mb-12  p-5">
      <div class="typography-text p-4">
          <p style="color:#4ade80" id="demo"></p>
        </div>
        <form class="database-login drop-shadow-md md:mb-0 bg-stone-800 p-5">
        
          <!-- Email input -->
          <div class="mb-6">
            <input type="text" value="localhost" name="hostname"
             class="form-control block w-full px-4 py-2 text-xl font-normal text-green-700  bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-green-700 focus:bg-stone-800 focus:border-lime-500	focus:border-b-1 focus:border-l-0 focus:border-r-0 focus:border-t-0 focus:outline-none"
              placeholder="localhost (127.0.0.1)"/>
          </div>
          <div class="mb-6">
            <input
              type="text" class="form-control block w-full px-4 py-2 text-xl font-normal text-green-700  bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-green-700 focus:bg-stone-800 focus:border-lime-500	focus:border-b-1 focus:border-l-0 focus:border-r-0 focus:border-t-0 focus:outline-none"
             id="exampleFormControlInput2"
              placeholder="username" value="root" name="username"
            />
          </div>
          <div class="mb-6">
            <input
              type="password" name="password"
              class="form-control block w-full px-4 py-2 text-xl font-normal text-green-700  bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-green-700 focus:bg-stone-800 focus:border-lime-500	focus:border-b-1 focus:border-l-0 focus:border-r-0 focus:border-t-0 focus:outline-none"
              id="exampleFormControlInput2"
              placeholder="Password"
            />
            <small class="text-white">Password should be empty domain: localhost</small>
          </div>
          <div class="mb-6">
            <input name="database_name"
              type="text"
              class="form-control block w-full px-4 py-2 text-xl font-normal text-green-700  bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-green-700 focus:bg-stone-800 focus:border-lime-500	focus:border-b-1 focus:border-l-0 focus:border-r-0 focus:border-t-0 focus:outline-none"
              id="exampleFormControlInput2"
              placeholder="database_name"
            />
          </div>
          

          

          <!-- Password input -->
          

          <div class="text-center lg:text-left">
            <button
              type="button"
              class="login-btn inline-block px-7 py-3 bg-blue-600 text-white font-medium text-sm leading-snug uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out"
            >
              Login
            </button>
            <p class="text-sm font-semibold text-pink-700 mt-2 pt-1 mb-0">
              Don't have an database ?
              <a
                href="#!"
                class="text-red-600 hover:text-red-700 focus:text-red-700 transition duration-200 ease-in-out"
                >Create one</a
              >
            </p>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>
<script>  
var i = 0;
var quote = [
  'In order to have a decentralised database, you need to have security. In order to have security, you need to - you need to have incentives.',
  'Computing should be taught as a rigorous - but fun - discipline covering topics like programming, database structures, and algorithms. That doesn\'t have to be boring...',
  'A database is information that is set up for easy access, management and updating. Computer databases typically store aggregations of data records or files that contain information, such as sales transactions, customer data, financials and product information',
  'Databases are used for storing, maintaining and accessing any sort of data. They collect information on people, places or things.',
  'Companies collect data about business processes, such sales, order processing and customer service. They analyze that data to improve these processes, expand their business and grow revenue',
  'Healthcare providers use databases to securely store personal health data to inform and improve patient care.'
]
var index = Math.floor(Math.random() * 10);
while(index > 6 ){
  index = Math.floor(Math.random() * 10);
}
var txt = quote[index];
var speed = 50;

function typeWriter() {
      if (i < txt.length) {
        document.getElementById("demo").innerHTML += txt.charAt(i);
        i++;
        setTimeout(typeWriter, speed);
      }
}
window.onload = typeWriter();

$(document).ready(function(){
  $(".login-btn").click(function(){
    if($("[name=database_name]").val() !=''){
      $.ajax({
        type:"POST",
        url:'check-coonect.php',
        data:{
          host:$("[name=hostname]").val(),
          username:$("[name=username]").val(),
          password:$("[name=password]").val(),
          databasename:$("[name=database_name]").val(),
        },
        success:function(r){
          if(r.trim() == 'done'){
            window.location.href = "dashboard";

          }
        }
      });
    }
  });  
});

</script>
</body>
</html>